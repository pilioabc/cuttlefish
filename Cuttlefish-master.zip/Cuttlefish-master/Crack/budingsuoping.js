/***********************************

> 應用名稱：布丁鎖屏
> 軟件版本：2.1.2
> 下載地址：https://apps.apple.com/cn/app/id1571268183
> 腳本作者：Cuttlefish
> 微信賬號：墨魚手記
> 更新時間：2022-02-21
> 通知頻道：https://t.me/ddgksf2021
> 問題反饋：https://t.me/ddgksf2013_bot
> 特別說明：本腳本僅供學習交流使用，禁止轉載售賣
 
[rewrite_local]

# ～ 布丁鎖屏解鎖會員權限（2022-02-21）@ddgksf2013
https?:\/\/screen-lock\.51wnl-cq\.com\/userApi\/saveUser url script-echo-response https://gitlab.com/ddgksf2013/Cuttlefish/-/raw/master/Crack/budingsuoping.js

[mitm] 

hostname=screen-lock.51wnl-cq.com

***********************************/



















var cuttlefish ={"warning":"本腳本僅供學習交流使用，禁止轉載售賣","tgchannel":"https://t.me/ddgksf2021","feedback":"https://t.me/ddgksf2013_bot"}
var ddgksf2013 = {"returncode":"SUCCESS","errormsg":"","data":{"id":"ddgksf2013","nickName":"公众号墨鱼手记","sign":"公众号墨鱼手记","vipStatus":1,"endTime":2099,"exchangeCode":null,"expireDate":null}};
$done({body: JSON.stringify(ddgksf2013)});