#### AD Block & Script Crack

### 💰 捐赠
本库的开发和更新等，都是墨鱼在业余时间独立进行，并免费开源使用，如果您认可我的脚本，并且觉得对你有所帮助，欢迎通过微信公众号或下面二维码捐赠墨鱼，谢谢🌹。

<table width="100%">
    <tr>
        <th>支付宝</th>
        <th>微信</th>
    </tr>
    <tr>
        <td><img alt="看不见图片请使用科学上网" src="https://gitlab.com/ddgksf2013/Cuttlefish/-/raw/master/Icon/alipay.jpg"></td>
        <td><img alt="看不见图片请使用科学上网" src="https://gitlab.com/ddgksf2013/Cuttlefish/-/raw/master/Icon/wechat.jpg"></td>
    </tr>
</table>


