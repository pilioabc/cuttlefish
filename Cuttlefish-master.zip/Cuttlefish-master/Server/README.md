### 魔法少女小圆的奇妙之旅
* 免费公益v2ray节点订阅地址[自助获取](https://www.v2rayfree.eu.org/post/free-v2ray)

<table>
    <tr>
	    <th>类别</th>
	    <th>地址</th>
	    <th>备注</th>
    </tr >
    <tr>
        <td rowspan="3">Windows</td>    
        <td ><a href="https://github.com/Fndroid/clash_for_windows_pkg/releases">Clash</a></td>
	<td>Fndroid</td>
    </tr>
    <tr>
    <td ><a href="https://github.do/https://github.com/Fndroid/clash_for_windows_pkg/releases/download/0.19.14/Clash.for.Windows.Setup.0.19.14.exe">镜像1</a></td> 
    <td></td>
    </tr>
    <tr>
        <td ><a href="https://ghproxy.com/?q=https%3A%2F%2Fgithub.com%2FFndroid%2Fclash_for_windows_pkg%2Freleases%2Fdownload%2F0.19.14%2FClash.for.Windows.Setup.0.19.14.exe">镜像2</a></td> 
    <td></td>
    </tr>
    <tr>
    </tr>
    <tr>
        <td>MacOS</td> 
        <td><a href="https://github.com/yichengchen/clashX/releases">Clash</a></td>
	<td></td>
   </tr>
   <tr>
        <td>安卓</td> 
        <td><a href="https://github.com/Kr328/ClashForAndroid/releases">Clash</a></td> 
	<td></td>
   </tr>
   <tr>
        <td rowspan="6">IOS付费</td>    
        <td ><a href="https://apps.apple.com/us/app/id932747118">Shadowrocket<br/>$2.99</a></td> 
	<td>最佳代理工具</td>
    </tr>
    <tr>  
        <td ><a href="https://apps.apple.com/us/app/id1443988620">QuantumultX<br/>$7.99</a></td>  
	<td>YYDS</td>
    </tr>
    <tr>  
        <td ><a href="https://apps.apple.com/us/app/id1373567447">Loon $4.99</a></td>  
	<td></td>
    </tr>
    <tr>  
        <td ><a href="https://apps.apple.com/us/app/id1442620678">Surge $49.99</a></td>  
	<td>功能性订阅</td>
    </tr>
    <tr>  
        <td ><a href="https://apps.apple.com/us/app/id1582542227">Choc $2.99</a></td>  
	<td></td>
    </tr>
    <tr>  
        <td ><a href="https://apps.apple.com/app/id1596063349">Stash $2.99</a></td> 
	<td></td>
    </tr>
</table>
