/***********************************

> 應用名稱：nicegram-unlimited-text
> 軟件版本：1.0.3
> 下載地址：https://apps.apple.com/cn/app/id1608870673
> 腳本作者：Cuttlefish
> 微信賬號：墨魚手記
> 解鎖說明：解鎖高級會員權限
> 更新時間：2022-04-10
> 通知頻道：https://t.me/ddgksf2021
> 問題反饋：https://t.me/ddgksf2013_bot
> 特別說明：本腳本僅供學習交流使用，禁止轉載售賣
 
[rewrite_local]

# ～ Nicegram解鎖會員權限（2022-04-10）@ddgksf2013
https?:\/\/restore-access\.indream\.app\/restoreAccess\?id=\d{5,10} url echo-response text/json echo-response https://gitlab.com/ddgksf2013/Cuttlefish/-/raw/master/Crack/nicegram_body.js

[mitm] 

hostname=restore-access.indream.app

***********************************/
